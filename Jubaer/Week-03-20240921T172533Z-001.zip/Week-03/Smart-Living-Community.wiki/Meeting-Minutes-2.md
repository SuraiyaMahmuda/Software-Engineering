# Meeting Notes - 09-09-2024

**Date/Duration/Platform:** `September 9, 2024`  `1 hour 30 minutes`  `Discord`  

**Start Time:** 7:30 PM  
**End Time:** 9:00 PM  


**Attendees:**  
- Solaimi Hamid (SH)  
- Shanjida Alam (SA)  
- Irtifa Haider (IH)  
- Hasneen Tamanna (HT)  
- Md.Tanvir Hossain Saon (TH)  
- Jubaer Ahmad Khan (JK)


## Decisions

1. Incomplete Sections of SRS will be done within the next meeting.
2. Review on completed section of SRS.
3. Application Name should be decided within the next meeting.
4. **TH** will provide the **Meeting Agenda 3** for the next meeting and 
   **JK** will provide the **Meeting Minutes 3** for the next meeting.


## Actions

| Action                            | Allocated Member(s) | Deadline      |
|:------------------------------------:|:--------------------------:|:---------------:|
| **Functional Requirement**         | IA,HT,JK,TH,SA,SH            | 10/09/2024    |
| **Non-Functional Requirement**     | IA,HT,JK,TH,SA,SH                       | 10/09/2024    |
| **Finalize Application Name**      | IA,HT,JK,TH,SA,SH              | 10/09/2024    |
| **Review on Completed section of SRS**              | IA,HT,JK,TH,SA,SH                       | 13/09/2024    |


