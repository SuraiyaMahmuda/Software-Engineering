# Meeting Notes - 10-09-2024

**Date/Duration/Platform:** `September 10, 2024`  `40 minutes`  `Classroom 101`  

**Start Time:** 12:50 PM  
**End Time:** 01:30 PM  


**Attendees:**  
- Solaimi Hamid (SH)  
- Shanjida Alam (SA)  
- Irtifa Haider (IH)  
- Hasneen Tamanna (HT)  
- Md.Tanvir Hossain Saon (TH)  
- Jubaer Ahmad Khan (JK)


## Decisions

1. Android Application name is initally named as "SmartApt".
2. A "Review" column will be introduced in Trello, where everyone can add their digital signature to review each assigned task.
3. The completed section of the SRS will be reviewed.
4. Functional requirements will be reallocated.
5. User stories will be improved to refine the SRS.
6. The final application name should be decided in the next meeting.
7. **SA** will provide the **Meeting Agenda 4** for the next meeting, and **IH** will provide the **Meeting Minutes 4** for the next meeting.


## Actions

| Action                            | Allocated Member(s) | Deadline      |
|:------------------------------------:|:--------------------------:|:---------------:|
| **Complete the Incomplete Sections of SRS**         | SA,TH            | 13/09/2024    |
| **Review Completed Sections of SRS**     | IH,HT,JK,TH,SA,SH                       | 14/09/2024    |
| **Improve User Stories**              | IH,HT,JK,TH,SA,SH                       | 14/09/2024    |


