# Date Time and Platform
 `14-SEPTEMBER-2024` `12:00 PM` `DISCORD VOICE CHANNEL` 

# Meeting Chair and Note Taker
  `Hasneen Tamanna` `Solaimi Hamid`

# Information Updates/Reminders

* The next 3-5 weeks, we are going to work on a project.

* Everyone should be able to use git, github wiki’s, Trello, Discord.

# Decisions Needed

  * Decision about the **Documentation tool** that will be used for the project.

  * Decision about the **Coding standard** that we will use for the project.

# General Items

*   Need a Trello board updated for this project and team. Actions and other details will be posted there. Columns used need to be decided. Someone needs to create and invite other team members.

*   Need a workspace in Discord project to track the time the team uses. Someone needs to create and invite team members (using email addresses). We need to decide when to create channels (related to topics) in workplace and need to do all communications there.

*   Need a Git-Hub account for this project. One team member will create a repo in Git-Hub and invite the rest of the team members.

*   Need Git-Hub wiki pages to document project details.

*   Allocate one/two team members to check SRS update. They should come up with at-least 2 Features which they will work on.

*   Allocate team members to present on the **Architectural design** that should be used for the project.