# Team and Title Details
<p align="center">
  <img src="images/project-name-motto.png" alt="image description" />
</p>

## Project Name: Smart Living Community

## Team Members: 
* Mst. Solaimi Hamid (ID-346) 
* Shanjida Alam (ID-353)
* Irtifa Haidar Ahona (ID-354)
* Tammana Totinee (ID-362)
* Md. Tanvir Hossain Saon (ID-388)
* Jubaer Ahmad Khan (ID-402)

# Overview of the Project

# Smart Living Community

## Project Overview

The **Smart Living Community** project is a digital platform designed to enhance the living experience in residential communities. It streamlines communication, improves service efficiency, and fosters a more connected environment for residents, property managers, and community committee members.

### Key Features

- **Maintenance Requests**: Residents can submit and track maintenance and plumbing requests online, ensuring quick responses and clear communication.
  
- **Notifications and Alerts**: Residents and committee members can receive and send notifications about community events, utility outages (e.g., water, power), and emergency situations (e.g., gas leaks, security breaches).
  
- **Utility and Payment Management**: The platform allows residents to view utility usage, bills, and receive reminders for rent or dues. Convenient online payment options are available, along with access to detailed billing history.
  
- **Community Engagement**: The platform includes a digital bulletin board for buying, selling, or trading items, and supports online polls or surveys, allowing residents to actively participate in community decisions.
  
- **Event and Facility Management**: Residents are notified about community events and new services. The system also allows for guest pass requests, while committee members can manage facility usage, monitor system performance, and send event notifications.
  
- **Security and Visitor Access**: Security officers can manage visitor logs, monitor live camera feeds, and send notifications about suspicious activities or individuals in the building.
  
- **Sustainability and Waste Management**: Educational campaigns on waste reduction and recycling practices are facilitated through the platform, along with notifications about waste collection schedules.

# Project flow screens and flow
![Alt text](images/Workflow.png)


# User Interface
- **Login:** When the user will go to the Login option in the system, they will get directed to the login interface where they must fill up the the input fields with required information, and click on the button 'Login'. The preview of the login interface will look like this,  
*This line was edited from the local file, not from Git wiki*

![Preview of the Login interface ](images/Login-interface.png)

 
# Usage
The Smart Living Community App is designed to provide a user friendly interface. Here describe the mechanics or flows of the project:
 **User Login:**
     **Login Screen:**  The user is presented with a login screen that requires their username and password.
     **Authentication:** The app authenticates the user's credentials with the server.
     **Success:** If the credentials are valid, the user is logged in and redirected to the dashboard.
     **Failure:** If the credentials are invalid, the user is presented with an error message and prompted to try again.

# Assests
The Smart Living Community project needs multiple assets which are:

Physical Infrastructure Assets:

1.Landscape designs, plants, trees, and smart irrigation systems.
2.Rooftop gardens and eco-friendly roofing materials.

Safety and Security Assets:
1.Emergency Alarm Asset
2.Video monitoring Asset

