# Meeting Notes - 06-09-2024

**Date/Duration/Platform:** `September 6, 2024`  `1 hour 30 minutes`  `Discord`  

**Start Time:** 3:00 PM  
**End Time:** 4:30 PM  


**Attendees:**  
- Solaimi Hamid (SH)  
- Shanjida Alam (SA)  
- Irtifa Haider (IH)  
- Hasneen Tamanna (HT)  
- Md.Tanvir Hossain Saon (TH)  
- Jubaer Ahmad Khan (JK)


## Decisions
1. We will use the following for the project:
   - **IDE:** Android Studio
   - **Language:** Java, XML
   - **Framework:** Android SDK
2. Two sections of the SRS were distributed to everyone.
3. **HT** will provide the **Meeting Agenda 2** for the next meeting.
4. The application name is still under consideration.


## Actions

| Action                            | Allocated Member(s) | Deadline      |
|:------------------------------------:|:--------------------------:|:---------------:|
| **Documentation Tool: Javadoc**    | JK                       | 16/09/2024    |
| **Documentation Tool: Doxygen**    | HT                       | 16/09/2024    |
| **Documentation Tool: Sphinx with Java support** | SA              | 16/09/2024    |
| **Coding Standard-1**              | IA                       | 16/09/2024    |
| **Coding Standard-2**              | SH                       | 16/09/2024    |
| **Coding Standard-3**              | TH                       | 16/09/2024    |

