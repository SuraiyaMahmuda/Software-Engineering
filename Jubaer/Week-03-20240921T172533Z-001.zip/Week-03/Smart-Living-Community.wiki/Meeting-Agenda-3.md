# Date Time and Platform
 `10-SEPTEMBER-2024` `12:50 PM` `Classroom 101` 
# Meeting Chair and Note Taker
  `Md.Tanvir Hossain Saon` `Md.Jubaer Ahmad Khan`
# Information Updates/Reminders
* The next 3-5 weeks, we are going to work on a project.
* Everyone should be able to use git, github wiki’s, Trello, Discord.
# Decisions Needed
  * Finalize updates to the Software Requirements Specification (SRS) for the upcoming project.
  * Review and refine user stories.

# General Items

* A Trello board needs to be created and updated for the project. Team members will post tasks and details there. Columns need to be decided, and one person should be assigned to create the board and invite others.
* A workspace on Discord should be set up to track team activity. One person should create the workspace, invite members using email addresses, and we need to determine when to create topic-specific channels. All team communication will take place there.
* A GitHub repository is required for the project. One team member will create it and invite the rest of the team to join.
* GitHub wiki pages should be set up to document project details and progress.
* Assign one or two members to review the SRS updates and identify at least two features they will work on.
* Assign one or two members to plan and design GitHub wiki pages, including a brief summary of their intended use for the upcoming project.
* Assign team members to select the programming language(s) that will be used for the project.
