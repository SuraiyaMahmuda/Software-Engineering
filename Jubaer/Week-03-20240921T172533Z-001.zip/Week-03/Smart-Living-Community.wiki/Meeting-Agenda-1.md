 # Date Time and Platform
 `05-SEPTEMBER-2024` `11:35 AM` `CSE203` 
# Meeting Chair and Note Taker
  `Irtifa Haider Ahona` `Shanjida Alam`
# Information Updates/Reminders
* We are going to work on a project.
* Everyone should be able to use git, github wiki’s, Trello, Discord.
# Decisions Needed
  *	Decision about the **programming language** that we will use in the project.

  *	Decision about the **frameworks** (for implementation purposes) that we will use in the project.

# General Items

*	Allocate one/two team members to check coding standards. They should come up with at-least 2 coding standards.

*	Allocate one/two team members to check documentation tool(s). They should come up with at-least 1/2 tools (with brief summary of the usage, advantages and disadvantages) for source code level documentation.

