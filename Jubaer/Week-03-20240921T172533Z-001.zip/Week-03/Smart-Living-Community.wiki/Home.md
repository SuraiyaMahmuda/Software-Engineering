Welcome to the Smart-Living-Community wiki!
